/**
 * kahn.js
 * Kahn's Algorithm — BFS-based Topological Sort
 * Honda RA621H Assembly Scheduling
 * Complexity: O(V + E)
 */

'use strict';

const Kahn = (() => {

  /* ─────────────────────────────────────
     BUILD GRAPH
     Input  : component array
     Output : { nodes, adj, radj, inDegree }
  ───────────────────────────────────── */
  function buildGraph(components) {
    const nodes    = new Map();   // id → component object
    const adj      = new Map();   // id → Set of successors
    const radj     = new Map();   // id → Set of predecessors
    const inDegree = new Map();   // id → number (count of incoming edges)

    for (const c of components) {
      nodes.set(c.id, c);
      adj.set(c.id, new Set());
      radj.set(c.id, new Set());
      inDegree.set(c.id, 0);
    }

    for (const c of components) {
      for (const dep of c.deps) {
        if (!nodes.has(dep)) continue;
        adj.get(dep).add(c.id);          // dep must finish before c
        radj.get(c.id).add(dep);
        inDegree.set(c.id, inDegree.get(c.id) + 1);
      }
    }

    return { nodes, adj, radj, inDegree };
  }

  /* ─────────────────────────────────────
     KAHN'S ALGORITHM — STEP RECORDER
     Returns full snapshot of every step
     so the UI can replay it step-by-step.
  ───────────────────────────────────── */
  function run(components) {
    const graph = buildGraph(components);
    const { nodes, adj, inDegree } = graph;

    // Working copy of in-degrees (mutated during algorithm)
    const degree = new Map(inDegree);

    const steps  = [];  // every iteration recorded here
    const order  = [];  // final sorted order
    const waves  = [];  // each BFS level = one wave

    // ── STEP 0: Initial state (before any processing) ──
    steps.push({
      phase:       'init',
      description: 'Hitung in-degree tiap node. Masukkan semua node dengan in-degree = 0 ke queue awal.',
      queue:       [...degree].filter(([, d]) => d === 0).map(([id]) => id),
      processed:   [],
      justDone:    [],
      justQueued:  [...degree].filter(([, d]) => d === 0).map(([id]) => id),
      waveIndex:   -1,
      degree:      new Map(degree),
      order:       [],
    });

    // Seed queue
    let queue = [...degree].filter(([, d]) => d === 0).map(([id]) => id);

    let waveIdx = 0;

    while (queue.length > 0) {
      const wave       = [...queue];
      const newQueue   = [];
      const justQueued = [];

      waves.push(wave);

      // ── STEP: Wave starts ──
      steps.push({
        phase:       'wave-start',
        description: `Wave ${waveIdx + 1}: ${wave.length} node siap diproses (semua predecessor sudah selesai).`,
        queue:       [...wave],
        processed:   [...order],
        justDone:    [],
        justQueued:  [],
        waveIndex:   waveIdx,
        degree:      new Map(degree),
        order:       [...order],
        wave,
      });

      for (const id of wave) {
        order.push(id);

        // Decrement successors
        const freed = [];
        for (const succ of adj.get(id)) {
          const d = degree.get(succ) - 1;
          degree.set(succ, d);
          if (d === 0) {
            newQueue.push(succ);
            freed.push(succ);
            justQueued.push(succ);
          }
        }

        // ── STEP: Process single node ──
        steps.push({
          phase:       'process',
          description: `Proses ${id} — "${nodes.get(id).name}". Kurangi in-degree semua successor.${freed.length ? ` Node baru masuk queue: ${freed.join(', ')}.` : ' Tidak ada successor baru yang siap.'}`,
          queue:       [...newQueue],
          processed:   [...order],
          justDone:    [id],
          justQueued:  freed,
          waveIndex:   waveIdx,
          degree:      new Map(degree),
          order:       [...order],
          activeNode:  id,
          wave,
        });
      }

      queue = newQueue;
      waveIdx++;
    }

    const valid = order.length === nodes.size;

    // ── STEP: Final ──
    steps.push({
      phase:       'done',
      description: valid
        ? `✓ Topological sort selesai. ${order.length} node diurutkan dalam ${waves.length} wave. Graph valid — tidak ada siklus.`
        : `⚠ Siklus terdeteksi! Hanya ${order.length}/${nodes.size} node yang bisa diurutkan.`,
      queue:       [],
      processed:   [...order],
      justDone:    [],
      justQueued:  [],
      waveIndex:   waveIdx - 1,
      degree:      new Map(degree),
      order:       [...order],
      valid,
    });

    return { graph, steps, order, waves, valid };
  }

  /* ─────────────────────────────────────
     COMPUTE STATS
  ───────────────────────────────────── */
  function stats(graph, waves) {
    const { nodes, adj, inDegree } = graph;
    const roots  = [...inDegree].filter(([, d]) => d === 0).map(([id]) => id);
    const leaves = [...adj].filter(([, s]) => s.size === 0).map(([id]) => id);
    const edgeCount = [...adj].reduce((s, [, set]) => s + set.size, 0);
    return {
      nodeCount:  nodes.size,
      edgeCount,
      rootCount:  roots.length,
      leafCount:  leaves.length,
      waveCount:  waves.length,
      maxWaveSize: Math.max(...waves.map(w => w.length)),
      avgWaveSize: (nodes.size / waves.length).toFixed(1),
    };
  }

  return { buildGraph, run, stats };
})();

window.Kahn = Kahn;
